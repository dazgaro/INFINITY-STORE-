<?php
// Affiche les erreurs PHP pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Paramètres de connexion MySQL (WampServer)
$host = "localhost";
$dbname = "site_inscription"; // ← ICI on met bien le bon nom
$username_db = "root";
$password_db = ""; // Mot de passe vide sur WAMP par défaut

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Si formulaire soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Nettoyage des données
    $username = htmlspecialchars(trim($_POST["username"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $number = htmlspecialchars(trim($_POST["number"]));
    $password = trim($_POST["password"]);

    // Vérification email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("❌ Adresse e-mail invalide.");
    }

    // Hachage du mot de passe
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Requête SQL préparée
    $sql = "INSERT INTO utilisateurs (username, email, phone, password)
            VALUES (:username, :email, :phone, :password)";
    
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            ':username' => $username,
            ':email' => $email,
            ':phone' => $number,
            ':password' => $hashedPassword
        ]);
        echo "✅ Inscription réussie ! <a href='login.html'>Se connecter</a>";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo "❌ Cette adresse e-mail est déjà utilisée.";
        } else {
            echo "❌ Erreur SQL : " . $e->getMessage();
        }
    }
} else {
    echo "Méthode non autorisée.";
}
?>
