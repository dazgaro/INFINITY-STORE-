<?php
session_start();

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}

// Vérifie que c'est bien un administrateur
if ($_SESSION["role"] !== "admin") {
    echo "⛔ Accès refusé. Cette page est réservée aux administrateurs.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Admin</title>
</head>
<body>
    <h1>Bienvenue dans le panneau d'administration</h1>
    <p>Bonjour, <?php echo htmlspecialchars($_SESSION["username"]); ?> 👑</p>
    <a href="../login/dashboard.php">Retour au tableau de bord</a> |
    <a href="../login/login.html">Déconnexion</a>
</body>
</html>