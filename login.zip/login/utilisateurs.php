<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "user") {
    header("Location: ../login/login.html");
    exit();
}

// Connexion à la base pour récupérer les produits
$pdo = new PDO("mysql:host=localhost;dbname=site_inscription", "root", "");
$produits = $pdo->query("SELECT * FROM produits ORDER BY date_ajout DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace utilisateur</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            flex-direction: row;
            gap: 20px;
            padding: 30px;
        }

        .produits, .formulaire {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-height: 90vh;
            overflow-y: auto;
        }

        .produit {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 15px;
            padding: 10px;
        }

        .produit h4 {
            margin: 0;
            color: #007bff;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        h2 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 🛒 Colonne Produits -->
        <div class="produits">
            <h2>🛍 Nos Produits</h2>
            <?php foreach ($produits as $p): ?>
                <div class="produit">
                    <h4><?= htmlspecialchars($p["nom"]) ?> — <?= number_format($p["prix"], 2) ?>€</h4>
                    <p><?= htmlspecialchars($p["description"]) ?></p>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- 📝 Colonne Formulaire -->
        <div class="formulaire">
            <h2>📋 Remplir le formulaire</h2>
            <form action="traitement_formulaire.php" method="POST">
                <input type="text" name="sujet" placeholder="Sujet de la demande" required>
                <textarea name="message" rows="6" placeholder="Votre message..." required></textarea>
                <button type="submit">Envoyer</button>
            </form>
        </div>
    </div>
</body>
</html>