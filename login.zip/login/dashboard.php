<?php 
session_start(); 

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}

// Récupération des informations de session
$username = $_SESSION["username"];
$role = $_SESSION["role"];

// Connexion à la BDD
$pdo = new PDO("mysql:host=localhost;dbname=site_inscription", "root", "");

// Ajout produit
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["ajouter_produit"])) {
    $nom = $_POST["nom"];
    $description = $_POST["description"];
    $prix = $_POST["prix"];
    
    // Gestion de l'upload d'image
    $image = '';
    if (isset($_FILES['image'])) {
        $uploadDir = '../uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        $targetPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            $image = $fileName;
        }
    }

    $stmt = $pdo->prepare("INSERT INTO produits (nom, description, prix, image) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nom, $description, $prix, $image]);
    $_SESSION['message'] = "✅ Produit ajouté avec succès.";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Suppression produit
if (isset($_GET['supprimer'])) {
    $id = $_GET['supprimer'];
    
    // Récupérer le nom de l'image pour la supprimer du serveur
    $stmt = $pdo->prepare("SELECT image FROM produits WHERE id = ?");
    $stmt->execute([$id]);
    $produit = $stmt->fetch();
    
    if ($produit['image']) {
        $filePath = '../uploads/' . $produit['image'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }
    
    $stmt = $pdo->prepare("DELETE FROM produits WHERE id = ?");
    $stmt->execute([$id]);
    $_SESSION['message'] = "🗑️ Produit supprimé avec succès.";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Modification produit
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["modifier_produit"])) {
    $id = $_POST["id"];
    $nom = $_POST["nom"];
    $description = $_POST["description"];
    $prix = $_POST["prix"];
    
    // Gestion de l'image
    $image = $_POST['image_actuelle'];
    if (!empty($_FILES['image']['name'])) {
        $uploadDir = '../uploads/';
        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        $targetPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            // Supprimer l'ancienne image si elle existe
            if ($image) {
                $oldFilePath = '../uploads/' . $image;
                if (file_exists($oldFilePath)) {
                    unlink($oldFilePath);
                }
            }
            $image = $fileName;
        }
    }
    
    $stmt = $pdo->prepare("UPDATE produits SET nom = ?, description = ?, prix = ?, image = ? WHERE id = ?");
    $stmt->execute([$nom, $description, $prix, $image, $id]);
    $_SESSION['message'] = "🔄 Produit modifié avec succès.";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Liste produits
$produits = $pdo->query("SELECT * FROM produits ORDER BY date_ajout DESC")->fetchAll();

// Liste commandes
$commandes = $pdo->query("
    SELECT c.id, c.nom_client, p.nom AS produit, c.quantite, c.date_commande
    FROM commandes c
    JOIN produits p ON c.produit_id = p.id
    ORDER BY c.date_commande DESC
")->fetchAll();

// Afficher les messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord - INFINITY STORE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="80" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="40" cy="60" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="30" r="1.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="90" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="70" cy="10" r="1.5" fill="rgba(255,255,255,0.1)"/></svg>');
            animation: float 20s infinite linear;
            pointer-events: none;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        .dashboard {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 25px;
            padding: 40px;
            max-width: 1200px;
            margin: 50px auto;
            box-shadow: 
                0 25px 50px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideIn 0.8s ease-out;
            position: relative;
            overflow: hidden;
        }

        .dashboard::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.05), transparent);
            animation: shimmer 4s infinite;
            pointer-events: none;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .welcome-section {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        h2 {
            color: #ffffff;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            background: linear-gradient(45deg, #fff, #f0f0f0, #fff);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: titleGlow 3s infinite alternate;
        }

        @keyframes titleGlow {
            0% { text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); }
            100% { text-shadow: 2px 2px 8px rgba(255, 255, 255, 0.3); }
        }

        .role-badge {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
            animation: pulse 2s infinite;
        }

        .role-admin {
            background: linear-gradient(135deg, #ff6b6b, #ee5a52);
            color: white;
            box-shadow: 0 5px 15px rgba(238, 90, 82, 0.4);
        }

        .role-user {
            background: linear-gradient(135deg, #4ecdc4, #44a08d);
            color: white;
            box-shadow: 0 5px 15px rgba(68, 160, 141, 0.4);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .admin-section {
            background: rgba(255, 107, 107, 0.1);
            border: 2px solid rgba(255, 107, 107, 0.3);
            border-radius: 20px;
            padding: 25px;
            margin: 30px 0;
            text-align: center;
            animation: adminGlow 3s infinite alternate;
        }

        @keyframes adminGlow {
            0% { box-shadow: 0 0 20px rgba(255, 107, 107, 0.2); }
            100% { box-shadow: 0 0 30px rgba(255, 107, 107, 0.4); }
        }

        .admin-section p {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.1rem;
            margin-bottom: 0;
        }

        .navigation {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .nav-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 16px 28px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 2px solid rgba(255, 255, 255, 0.2);
            position: relative;
            overflow: hidden;
            min-width: 180px;
            justify-content: center;
        }

        .nav-link.admin-link {
            background: linear-gradient(135deg, #ff6b6b, #ee5a52);
            box-shadow: 0 8px 20px rgba(238, 90, 82, 0.3);
            border-color: transparent;
        }

        .nav-link.home-link {
            background: linear-gradient(135deg, #4ecdc4, #44a08d);
            box-shadow: 0 8px 20px rgba(68, 160, 141, 0.3);
            border-color: transparent;
        }

        .nav-link.logout-link {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            box-shadow: 0 8px 20px rgba(127, 140, 141, 0.3);
            border-color: transparent;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .nav-link:hover::before {
            left: 100%;
        }

        .nav-link:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .nav-link:active {
            transform: translateY(-1px) scale(1.02);
        }

        .emoji {
            font-size: 1.2em;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-5px); }
            60% { transform: translateY(-3px); }
        }

        .floating-icon {
            position: absolute;
            font-size: 1.5rem;
            opacity: 0.1;
            animation: floatIcon 12s infinite ease-in-out;
            color: white;
        }

        .floating-icon:nth-child(1) {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating-icon:nth-child(2) {
            top: 20%;
            right: 15%;
            animation-delay: 4s;
        }

        .floating-icon:nth-child(3) {
            bottom: 20%;
            left: 20%;
            animation-delay: 8s;
        }

        .floating-icon:nth-child(4) {
            bottom: 15%;
            right: 10%;
            animation-delay: 6s;
        }

        @keyframes floatIcon {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            33% { transform: translateY(-15px) rotate(5deg); }
            66% { transform: translateY(-25px) rotate(-5deg); }
        }

        .separator {
            margin: 40px auto;
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.5), transparent);
            border: none;
            border-radius: 2px;
        }

        .admin-content {
            text-align: left;
            margin-top: 30px;
        }

        .section-title {
            color: #ffffff;
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 25px;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .product-form {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 40px;
            box-shadow: 
                0 15px 35px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.3);
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-input, .form-textarea {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid rgba(102, 126, 234, 0.2);
            border-radius: 12px;
            font-size: 1rem;
            font-family: inherit;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s ease;
            outline: none;
        }

        .form-input:focus, .form-textarea:focus {
            border-color: #667eea;
            background: rgba(255, 255, 255, 1);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            transform: translateY(-2px);
        }

        .form-textarea {
            resize: vertical;
            min-height: 100px;
        }

        .submit-btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
            position: relative;
            overflow: hidden;
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        .submit-btn:active {
            transform: translateY(-1px);
        }

        .table-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            overflow: hidden;
            margin-bottom: 40px;
            box-shadow: 
                0 15px 35px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.3);
            animation: fadeInUp 0.6s ease-out;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        .data-table thead {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .data-table th, .data-table td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .data-table th {
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 0.9rem;
        }

        .data-table tbody tr {
            transition: all 0.3s ease;
        }

        .data-table tbody tr:hover {
            background: rgba(102, 126, 234, 0.05);
            transform: translateX(5px);
        }

        .data-table tbody tr:nth-child(even) {
            background: rgba(0, 0, 0, 0.02);
        }

        .data-table tbody tr:nth-child(even):hover {
            background: rgba(102, 126, 234, 0.08);
        }

        .price {
            font-weight: 700;
            color: #28a745;
        }

        .quantity {
            font-weight: 600;
            color: #667eea;
            text-align: center;
        }

        /* Styles pour les boutons d'action */
        .edit-btn, .delete-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s;
            margin: 2px;
        }

        .edit-btn {
            background: #4ecdc4;
            color: white;
        }

        .delete-btn {
            background: #ff6b6b;
            color: white;
            text-decoration: none;
            display: inline-block;
            padding: 8px 12px;
        }

        .edit-btn:hover {
            background: #44a08d;
            transform: translateY(-2px);
        }

        .delete-btn:hover {
            background: #ee5a52;
            transform: translateY(-2px);
        }

        /* Styles pour la modale */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 600px;
            width: 90%;
            animation: slideIn 0.3s;
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .dashboard {
                padding: 30px 20px;
                margin: 20px auto;
            }
            
            h2 {
                font-size: 2rem;
            }
            
            .navigation {
                flex-direction: column;
                align-items: center;
            }
            
            .nav-link {
                width: 100%;
                max-width: 280px;
            }
            
            .section-title {
                font-size: 1.5rem;
            }
            
            .product-form {
                padding: 20px;
            }
            
            .form-input, .form-textarea {
                padding: 12px 15px;
            }
            
            .data-table {
                font-size: 0.85rem;
            }
            
            .data-table th, .data-table td {
                padding: 10px 12px;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            .data-table {
                min-width: 600px;
            }
        }

        @media (max-width: 480px) {
            .dashboard {
                padding: 20px 15px;
                margin: 10px auto;
            }
            
            h2 {
                font-size: 1.8rem;
            }
            
            .section-title {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
    <div class="floating-icon">📊</div>
    <div class="floating-icon">👤</div>
    <div class="floating-icon">⚙️</div>
    <div class="floating-icon">🚀</div>
    
    <div class="dashboard">
        <div class="welcome-section">
            <h2>Bienvenue, <?php echo htmlspecialchars($username); ?> <span class="emoji">👋</span></h2>
            <div class="role-badge <?php echo $role === 'admin' ? 'role-admin' : 'role-user'; ?>">
                <?php echo $role === 'admin' ? '👑 ' : '👤 '; ?>
                <?php echo htmlspecialchars($role); ?>
            </div>
            
            <hr class="separator">

            <div class="admin-content">
                <h3 class="section-title">➕ Ajouter un produit</h3>
                <form method="POST" class="product-form" enctype="multipart/form-data">
                    <input type="hidden" name="ajouter_produit" value="1">
                    <div class="form-group">
                        <input type="text" name="nom" placeholder="Nom du produit" required class="form-input">
                    </div>
                    <div class="form-group">
                        <textarea name="description" placeholder="Description" rows="3" class="form-textarea"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="number" step="0.01" name="prix" placeholder="Prix (€)" required class="form-input">
                    </div>
                    <div class="form-group">
                        <input type="file" name="image" accept="image/*" class="form-input">
                    </div>
                    <button type="submit" class="submit-btn">
                        <span class="emoji">✨</span>
                        Ajouter le produit
                    </button>
                </form>

                <h3 class="section-title">📦 Produits disponibles</h3>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Nom</th>
                                <th>Description</th>
                                <th>Prix</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($produits as $p): ?>
                            <tr>
                                <td>
                                    <?php if ($p['image']): ?>
                                        <img src="../uploads/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['nom']) ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                    <?php else: ?>
                                        <span>No image</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($p["nom"]) ?></td>
                                <td><?= htmlspecialchars($p["description"]) ?></td>
                                <td class="price"><?= number_format($p["prix"], 2) ?> €</td>
                                <td><?= $p["date_ajout"] ?></td>
                                <td>
                                    <button class="edit-btn" onclick="openEditModal(<?= $p['id'] ?>, '<?= addslashes($p['nom']) ?>', '<?= addslashes($p['description']) ?>', <?= $p['prix'] ?>, '<?= $p['image'] ?>')">
                                        ✏️ Modifier
                                    </button>
                                    <a href="?supprimer=<?= $p['id'] ?>" class="delete-btn" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')">
                                        🗑️ Supprimer
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <h3 class="section-title">🧾 Commandes reçues</h3>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Produit</th>
                                <th>Quantité</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($commandes as $c): ?>
                            <tr>
                                <td><?= htmlspecialchars($c["nom_client"]) ?></td>
                                <td><?= htmlspecialchars($c["produit"]) ?></td>
                                <td class="quantity"><?= $c["quantite"] ?></td>
                                <td><?= $c["date_commande"] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if ($role === "admin") : ?>
            <div class="admin-section">
                <p>
                    <span class="emoji">🛠</span> 
                    Vous avez accès aux fonctionnalités d'administration
                </p>
            </div>
        <?php endif; ?>

        <div class="navigation">
            <a href="../acceuil/acceuil.html" class="nav-link home-link">
                <span class="emoji">🏠</span>
                Accueil
            </a>
            
            <a href="../login/login.html" class="nav-link logout-link">
                <span class="emoji">🚪</span>
                Déconnexion
            </a>
        </div>
    </div>

    <!-- Modale de modification -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h3 style="margin-bottom: 20px;">Modifier le produit</h3>
            <form method="POST" enctype="multipart/form-data" id="editForm">
                <input type="hidden" name="modifier_produit" value="1">
                <input type="hidden" name="id" id="editId">
                <input type="hidden" name="image_actuelle" id="editImageActuelle">
                
                <div class="form-group">
                    <input type="text" name="nom" id="editNom" placeholder="Nom du produit" required class="form-input">
                </div>
                <div class="form-group">
                    <textarea name="description" id="editDescription" placeholder="Description" rows="3" class="form-textarea"></textarea>
                </div>
                <div class="form-group">
                    <input type="number" step="0.01" name="prix" id="editPrix" placeholder="Prix (€)" required class="form-input">
                </div>
                <div class="form-group">
                    <label>Image actuelle:</label>
                    <img id="editImagePreview" src="" style="max-width: 100px; max-height: 100px; display: block; margin: 10px 0;">
                    <input type="file" name="image" accept="image/*" class="form-input">
                    <small>Laisser vide pour conserver l'image actuelle</small>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="submit-btn" style="flex: 1;">
                        <span class="emoji">💾</span>
                        Enregistrer
                    </button>
                    <button type="button" onclick="closeEditModal()" class="submit-btn" style="flex: 1; background: #95a5a6;">
                        <span class="emoji">❌</span>
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // Fonctions pour la modale
    function openEditModal(id, nom, description, prix, image) {
        document.getElementById('editId').value = id;
        document.getElementById('editNom').value = nom;
        document.getElementById('editDescription').value = description;
        document.getElementById('editPrix').value = prix;
        document.getElementById('editImageActuelle').value = image;
        
        const preview = document.getElementById('editImagePreview');
        if (image) {
            preview.src = '../uploads/' + image;
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
        
        document.getElementById('editModal').style.display = 'flex';
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }

    // Afficher les messages flash
    <?php if (isset($message)): ?>
        alert('<?= addslashes($message) ?>');
    <?php endif; ?>
    </script>
</body>
</html>